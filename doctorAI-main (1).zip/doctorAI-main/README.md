# doctorAI
democratizing healthcare through a simulated online check up

# Dependencies
```bash
npm install express
npm install jquery
npm install body-parser
npm install jade
```